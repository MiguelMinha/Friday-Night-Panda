function onCreate()
    makeLuaSprite('background', 'stages/PandaBG/PandaBG', 0, 0)
    setScrollFactor('background', 0.9, 0.9)
    addLuaSprite('background', false)
end