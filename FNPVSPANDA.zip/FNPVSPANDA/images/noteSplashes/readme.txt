This is where you're supposed to put your Note Splashes.
Note splashes need 3 files with the same names:

noteSplashes-my_skin.txt - You can make it through the Note Splash Debug (press 7 on Main Menu)
noteSplashes-my_skin.png
noteSplashes-my_skin.xml

To add your note splash to the list, make a list.txt file on this folder and add your skin name, if you want to add multiple skins, do it like this:

My Skin 1
My Skin 2
My Skin 3